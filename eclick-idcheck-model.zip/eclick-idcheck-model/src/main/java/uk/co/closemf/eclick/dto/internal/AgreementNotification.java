package uk.co.closemf.eclick.dto.internal;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class AgreementNotification extends DocumentNotification {

	private static final long serialVersionUID = 6668392530361558429L;
	private String verificationResult;


    public void setVerificationResult(String string) {
        this.verificationResult = string;
    }

    public String getVerificationResult() {
        return verificationResult;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
