package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Java class for BankAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankAccount">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AccountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SortCode1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SortCode2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SortCode3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountHolderMonths" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="AccountHolderYears" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankAccount", propOrder = { "accountNumber", "accountHolder", "sortCode1", "sortCode2", "sortCode3", "bankName",
        "accountHolderMonths", "accountHolderYears" })
public class BankAccount implements Serializable{

	private static final long serialVersionUID = 8349187796745068566L;
	@XmlElement(name = "AccountNumber", required = true)
    protected String accountNumber;
    @XmlElement(name = "AccountHolder")
    protected String accountHolder;
    @XmlElement(name = "SortCode1", required = true)
    protected String sortCode1;
    @XmlElement(name = "SortCode2", required = true)
    protected String sortCode2;
    @XmlElement(name = "SortCode3", required = true)
    protected String sortCode3;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "AccountHolderMonths")
    protected int accountHolderMonths;
    @XmlElement(name = "AccountHolderYears")
    protected int accountHolderYears;


    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountHolder(String value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the sortCode1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSortCode1() {
        return sortCode1;
    }

    /**
     * Sets the value of the sortCode1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSortCode1(String value) {
        this.sortCode1 = value;
    }

    /**
     * Gets the value of the sortCode2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSortCode2() {
        return sortCode2;
    }

    /**
     * Sets the value of the sortCode2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSortCode2(String value) {
        this.sortCode2 = value;
    }

    /**
     * Gets the value of the sortCode3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSortCode3() {
        return sortCode3;
    }

    /**
     * Sets the value of the sortCode3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSortCode3(String value) {
        this.sortCode3 = value;
    }

    /**
     * Gets the value of the bankName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Sets the value of the bankName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Gets the value of the accountHolderMonths property.
     * 
     */
    public int getAccountHolderMonths() {
        return accountHolderMonths;
    }

    /**
     * Sets the value of the accountHolderMonths property.
     * 
     */
    public void setAccountHolderMonths(int value) {
        this.accountHolderMonths = value;
    }

    /**
     * Gets the value of the accountHolderYears property.
     * 
     */
    public int getAccountHolderYears() {
        return accountHolderYears;
    }

    /**
     * Sets the value of the accountHolderYears property.
     * 
     */
    public void setAccountHolderYears(int value) {
        this.accountHolderYears = value;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
    

}
