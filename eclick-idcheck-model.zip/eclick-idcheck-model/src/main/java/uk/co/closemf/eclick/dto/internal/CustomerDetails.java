package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerDetails", propOrder = {
    "personalDetails",
    "address",
    "bankAccount",
    "passport",
    "drivingLicence",
    "roleType"
})

@XmlRootElement(name="CustomerDetails")
public class CustomerDetails implements Serializable{

	private static final long serialVersionUID = -2016228618414412559L;
	@XmlElement(name = "PersonalDetails", required = true)
    protected PersonalDetails personalDetails;
    @XmlElement(name = "Address")
    private List<Address> address;
    @XmlElement(name = "BankAccount")
    protected BankAccount bankAccount;
    @XmlElement(name = "Passport")
    protected Passport passport;
    @XmlElement(name = "DrivingLicence")
    protected DrivingLicence drivingLicence;
    @XmlElement(name = "RoleType")
    protected RoleType roleType;

    /**
     * Gets the value of the personalDetails property.
     * 
     * @return possible object is {@link PersonalDetails }
     * 
     */
    public PersonalDetails getPersonalDetails() {
        return personalDetails;
    }

    /**
     * Sets the value of the personalDetails property.
     * 
     * @param value
     *            allowed object is {@link PersonalDetails }
     * 
     */
    public void setPersonalDetails(PersonalDetails value) {
        this.personalDetails = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list {@link Address }
     * 
     * 
     */
    public List<Address> getAddress() {
        if (address == null) {
            address = new ArrayList<>();
        }
        return this.address;
    }

    /**
     * Gets the value of the bankAccount property.
     * 
     * @return possible object is {@link BankAccount }
     * 
     */
    public BankAccount getBankAccount() {
        return bankAccount;
    }

    /**
     * Sets the value of the bankAccount property.
     * 
     * @param value
     *            allowed object is {@link BankAccount }
     * 
     */
    public void setBankAccount(BankAccount value) {
        this.bankAccount = value;
    }

    /**
     * Gets the value of the passport property.
     * 
     * @return possible object is {@link Passport }
     * 
     */
    public Passport getPassport() {
        return passport;
    }

    /**
     * Sets the value of the passport property.
     * 
     * @param value
     *            allowed object is {@link Passport }
     * 
     */
    public void setPassport(Passport value) {
        this.passport = value;
    }

    /**
     * Gets the value of the drivingLicence property.
     * 
     * @return possible object is {@link DrivingLicence }
     * 
     */
    public DrivingLicence getDrivingLicence() {
        return drivingLicence;
    }

    /**
     * Sets the value of the drivingLicence property.
     * 
     * @param value
     *            allowed object is {@link DrivingLicence }
     * 
     */
    public void setDrivingLicence(DrivingLicence value) {
        this.drivingLicence = value;
    }

    /**
     * Gets the value of the roleType property.
     * 
     * @return possible object is {@link RoleType }
     * 
     */
    public RoleType getRoleType() {
        return roleType;
    }

    /**
     * Sets the value of the roleType property.
     * 
     * @param value
     *            allowed object is {@link RoleType }
     * 
     */
    public void setRoleType(RoleType value) {
        this.roleType = value;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
