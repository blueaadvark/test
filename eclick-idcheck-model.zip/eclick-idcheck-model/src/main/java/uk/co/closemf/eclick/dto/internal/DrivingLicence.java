package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Java class for DrivingLicence complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DrivingLicence">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Number1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Number2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Number3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Number4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MailSort" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Postcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Microfiche" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IssueDay" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IssueMonth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IssueYear" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DrivingLicence", propOrder = { "number1", "number2", "number3", "number4", "mailSort", "postcode", "microfiche",
        "issueDay", "issueMonth", "issueYear" })
public class DrivingLicence implements Serializable{

	private static final long serialVersionUID = -7197960658956859662L;
	@XmlElement(name = "Number1", required = true)
    protected String number1;
    @XmlElement(name = "Number2", required = true)
    protected String number2;
    @XmlElement(name = "Number3", required = true)
    protected String number3;
    @XmlElement(name = "Number4", required = true)
    protected String number4;
    @XmlElement(name = "MailSort", required = true)
    protected String mailSort;
    @XmlElement(name = "Postcode", required = true)
    protected String postcode;
    @XmlElement(name = "Microfiche")
    protected String microfiche;
    @XmlElement(name = "IssueDay")
    protected int issueDay;
    @XmlElement(name = "IssueMonth")
    protected int issueMonth;
    @XmlElement(name = "IssueYear")
    protected int issueYear;


    /**
     * Gets the value of the number1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber1() {
        return number1;
    }

    /**
     * Sets the value of the number1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber1(String value) {
        this.number1 = value;
    }

    /**
     * Gets the value of the number2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber2() {
        return number2;
    }

    /**
     * Sets the value of the number2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber2(String value) {
        this.number2 = value;
    }

    /**
     * Gets the value of the number3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber3() {
        return number3;
    }

    /**
     * Sets the value of the number3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber3(String value) {
        this.number3 = value;
    }

    /**
     * Gets the value of the number4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber4() {
        return number4;
    }

    /**
     * Sets the value of the number4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber4(String value) {
        this.number4 = value;
    }

    /**
     * Gets the value of the mailSort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailSort() {
        return mailSort;
    }

    /**
     * Sets the value of the mailSort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailSort(String value) {
        this.mailSort = value;
    }

    /**
     * Gets the value of the postcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * Sets the value of the postcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostcode(String value) {
        this.postcode = value;
    }

    /**
     * Gets the value of the microfiche property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMicrofiche() {
        return microfiche;
    }

    /**
     * Sets the value of the microfiche property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMicrofiche(String value) {
        this.microfiche = value;
    }

    /**
     * Gets the value of the issueDay property.
     * 
     */
    public int getIssueDay() {
        return issueDay;
    }

    /**
     * Sets the value of the issueDay property.
     * 
     */
    public void setIssueDay(int value) {
        this.issueDay = value;
    }

    /**
     * Gets the value of the issueMonth property.
     * 
     */
    public int getIssueMonth() {
        return issueMonth;
    }

    /**
     * Sets the value of the issueMonth property.
     * 
     */
    public void setIssueMonth(int value) {
        this.issueMonth = value;
    }

    /**
     * Gets the value of the issueYear property.
     * 
     */
    public int getIssueYear() {
        return issueYear;
    }

    /**
     * Sets the value of the issueYear property.
     * 
     */
    public void setIssueYear(int value) {
        this.issueYear = value;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
