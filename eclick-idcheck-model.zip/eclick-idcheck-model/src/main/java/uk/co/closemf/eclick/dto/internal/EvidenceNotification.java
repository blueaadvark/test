/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.dto.internal;

/**
 * @author tasmith
 * 
 */
public class EvidenceNotification extends DocumentNotification {

	private static final long serialVersionUID = -7229704911681000986L;

}
