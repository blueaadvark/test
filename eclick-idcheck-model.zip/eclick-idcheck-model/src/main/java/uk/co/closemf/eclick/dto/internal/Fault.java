package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Fault implements Serializable{

	private static final long serialVersionUID = 6066351068416188704L;
	protected String faultCategory;
    private List<FaultDetail> faultDetails = new ArrayList<>();


    public Fault() {
    }

    public Fault(List<FaultDetail> faultDetails) {
        getFaultDetail().addAll(faultDetails);
    }

    /**
     * Gets the value of the faultCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaultCategory() {
        return faultCategory;
    }

    /**
     * Sets the value of the faultCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaultCategory(String value) {
        this.faultCategory = value;
    }

    /**
     * Gets the value of the faultDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the faultDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFaultDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FaultDetail }
     * 
     * 
     */
    public List<FaultDetail> getFaultDetail() {
        if (faultDetails == null) {
            faultDetails = new ArrayList<>();
        }
        return this.faultDetails;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }

}
