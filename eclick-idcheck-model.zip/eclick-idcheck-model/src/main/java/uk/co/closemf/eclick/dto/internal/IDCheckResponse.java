package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XmlRootElement(name="IDCheckResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class IDCheckResponse implements Serializable{

	private static final long serialVersionUID = 2397537258670527639L;
	
	@XmlElement(name = "IDCheckIdentifier")
	private String idCheckIdentifier;
	@XmlElement(name = "ServiceStatus")
	private ServiceStatusValues serviceStatus;
	@XmlElement(name = "IDCheckXML")
	private String idCheckXML;
    @XmlElement(name = "Fault")
    private List<Fault> fault = new ArrayList<>();
    private Date timestamp;
    private String correlationId;
    private String replyTo;
    
    public IDCheckResponse() {
        super();
    }

    public IDCheckResponse(List<Fault> faults, Date timestamp) {
        this();
        serviceStatus = ServiceStatusValues.ERROR;
        this.fault.addAll(faults);
        this.timestamp = timestamp;
    }

    /**
     * Gets the value of the serviceStatus property.
     * 
     * @return possible object is {@link ServiceStatusValues }
     * 
     */
    public ServiceStatusValues getServiceStatus() {
        return serviceStatus;
    }

    /**
     * Sets the value of the serviceStatus property.
     * 
     * @param value
     *            allowed object is {@link ServiceStatusValues }
     * 
     */
    public void setServiceStatus(ServiceStatusValues value) {
        this.serviceStatus = value;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public String getIdCheckIdentifier() {
        return idCheckIdentifier;
    }

    public void setIdCheckIdentifier(String idCheckIdentifier) {
        this.idCheckIdentifier = idCheckIdentifier;
    } 

    public String getIdCheckXML() {
        return idCheckXML;
    }

    public void setIdCheckXML(String idCheckXML) {
        this.idCheckXML = idCheckXML;
    }

    /**
     * Gets the value of the fault property. To add a new item, do as follows:
     * 
     * <pre>
     * getFault().add(newItem);
     * </pre>
     * 
     * Objects of the following type(s) are allowed in the list {@link Fault }
     * 
     * 
     */
    public List<Fault> getFault() {
        if (fault == null) {
            fault = new ArrayList<>();
        }
        return this.fault;
    }

    public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	@Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
