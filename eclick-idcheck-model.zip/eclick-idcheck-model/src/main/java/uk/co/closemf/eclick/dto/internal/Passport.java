package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Java class for Passport complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Passport">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Passportline1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Passportline2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExpiryDay" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ExpiryMonth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ExpiryYear" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Passport", propOrder = { "passportline1", "passportline2", "expiryDay", "expiryMonth", "expiryYear" })
public class Passport implements Serializable{

	private static final long serialVersionUID = -966009262275042832L;
	@XmlElement(name = "Passportline1", required = true)
    protected String passportline1;
    @XmlElement(name = "Passportline2", required = true)
    protected String passportline2;
    @XmlElement(name = "ExpiryDay")
    protected int expiryDay;
    @XmlElement(name = "ExpiryMonth")
    protected int expiryMonth;
    @XmlElement(name = "ExpiryYear")
    protected int expiryYear;


    /**
     * Gets the value of the passportline1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassportline1() {
        return passportline1;
    }

    /**
     * Sets the value of the passportline1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassportline1(String value) {
        this.passportline1 = value;
    }

    /**
     * Gets the value of the passportline2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassportline2() {
        return passportline2;
    }

    /**
     * Sets the value of the passportline2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassportline2(String value) {
        this.passportline2 = value;
    }

    /**
     * Gets the value of the expiryDay property.
     * 
     */
    public int getExpiryDay() {
        return expiryDay;
    }

    /**
     * Sets the value of the expiryDay property.
     * 
     */
    public void setExpiryDay(int value) {
        this.expiryDay = value;
    }

    /**
     * Gets the value of the expiryMonth property.
     * 
     */
    public int getExpiryMonth() {
        return expiryMonth;
    }

    /**
     * Sets the value of the expiryMonth property.
     * 
     */
    public void setExpiryMonth(int value) {
        this.expiryMonth = value;
    }

    /**
     * Gets the value of the expiryYear property.
     * 
     */
    public int getExpiryYear() {
        return expiryYear;
    }

    /**
     * Sets the value of the expiryYear property.
     * 
     */
    public void setExpiryYear(int value) {
        this.expiryYear = value;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
