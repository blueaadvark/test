package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Java class for PersonalDetails complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="PersonalDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Forename" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Surname" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FormerSurname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Gender" type="{http://closemf.co.uk/id/enums}Gender"/>
 *         &lt;element name="DOBDay" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="DOBMonth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="DOBYear" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidenceType" type="{http://closemf.co.uk/id/enums}ResidenceType"/>
 *         &lt;element name="Telephone" type="{http://closemf.co.uk/id/types}Telephone" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonalDetails", propOrder = { "title", "forename", "middleName", "surname", "formerSurname", "gender", "dobDay",
        "dobMonth", "dobYear", "email", "residenceType", "telephones", "phone" })
public class PersonalDetails implements Serializable {

	private static final long serialVersionUID = -5181694798485552127L;
	@XmlElement(name = "Title")
    protected String title;
    @XmlElement(name = "Forename", required = true)
    protected String forename;
    @XmlElement(name = "MiddleName")
    protected String middleName;
    @XmlElement(name = "Surname", required = true)
    protected String surname;
    @XmlElement(name = "FormerSurname")
    protected String formerSurname;
    @XmlElement(name = "Gender", required = true, nillable = true)
    protected Gender gender;
    @XmlElement(name = "DOBDay", required = true, type = Integer.class, nillable = true)
    protected Integer dobDay;
    @XmlElement(name = "DOBMonth", required = true, type = Integer.class, nillable = true)
    protected Integer dobMonth;
    @XmlElement(name = "DOBYear", required = true, type = Integer.class, nillable = true)
    protected Integer dobYear;
    @XmlElement(name = "Email")
    protected String email;
    @XmlElement(name = "ResidenceType", required = true, nillable = true)
    protected ResidenceType residenceType;
    @XmlElement(name = "Telephone")
    private List<Telephone> telephones;
    protected Telephone phone;


    /**
     * Gets the value of the title property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the forename property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getForename() {
        return forename;
    }

    /**
     * Sets the value of the forename property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setForename(String value) {
        this.forename = value;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Gets the value of the surname property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the value of the surname property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setSurname(String value) {
        this.surname = value;
    }

    /**
     * Gets the value of the formerSurname property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getFormerSurname() {
        return formerSurname;
    }

    /**
     * Sets the value of the formerSurname property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setFormerSurname(String value) {
        this.formerSurname = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return possible object is {@link Gender }
     * 
     */
    public Gender getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *            allowed object is {@link Gender }
     * 
     */
    public void setGender(Gender value) {
        this.gender = value;
    }

    /**
     * Gets the value of the dobDay property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDOBDay() {
        return dobDay;
    }

    /**
     * Sets the value of the dobDay property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDOBDay(Integer value) {
        this.dobDay = value;
    }

    /**
     * Gets the value of the dobMonth property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDOBMonth() {
        return dobMonth;
    }

    /**
     * Sets the value of the dobMonth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDOBMonth(Integer value) {
        this.dobMonth = value;
    }

    /**
     * Gets the value of the dobYear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDOBYear() {
        return dobYear;
    }

    /**
     * Sets the value of the dobYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDOBYear(Integer value) {
        this.dobYear = value;
    }


    /**
     * Gets the value of the email property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the residenceType property.
     * 
     * @return possible object is {@link ResidenceType }
     * 
     */
    public ResidenceType getResidenceType() {
        return residenceType;
    }

    /**
     * Sets the value of the residenceType property.
     * 
     * @param value
     *            allowed object is {@link ResidenceType }
     * 
     */
    public void setResidenceType(ResidenceType value) {
        this.residenceType = value;
    }

    /**
     * Gets the value of the telephone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the telephone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getTelephone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Telephone }
     * 
     * 
     */
    public void add(Telephone entry) {
        telephones.add(entry);
    }

    public List<Telephone> getTelephones() {
        if (telephones == null) {
            telephones = new ArrayList<>();
        }
        return this.telephones;
    }

    public Telephone getTelephone() {
        return this.phone;
    }

    public void setTelephone(Telephone list) {
        this.phone = list;
    }

    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
