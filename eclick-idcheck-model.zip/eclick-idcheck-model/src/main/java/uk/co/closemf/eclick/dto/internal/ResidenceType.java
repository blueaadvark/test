package uk.co.closemf.eclick.dto.internal;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for ResidenceType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ResidenceType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HomeOwnerOutright"/>
 *     &lt;enumeration value="HomeOwnerMortgage"/>
 *     &lt;enumeration value="Tenant"/>
 *     &lt;enumeration value="LivingWithRelatives"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ResidenceType", namespace = "http://closemf.co.uk/id/enums")
@XmlEnum
public enum ResidenceType {

    @XmlEnumValue("HomeOwnerOutright")
    HOME_OWNER_OUTRIGHT("HomeOwnerOutright"), @XmlEnumValue("HomeOwnerMortgage")
    HOME_OWNER_MORTGAGE("HomeOwnerMortgage"), @XmlEnumValue("Tenant")
    TENANT("Tenant"), @XmlEnumValue("LivingWithRelatives")
    LIVING_WITH_RELATIVES("LivingWithRelatives");

    private final String value;


    ResidenceType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ResidenceType fromValue(String v) {
        for (ResidenceType c : ResidenceType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
