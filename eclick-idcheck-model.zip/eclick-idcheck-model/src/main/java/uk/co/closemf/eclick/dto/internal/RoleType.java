package uk.co.closemf.eclick.dto.internal;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for RoleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RoleType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="APPLICANT1"/>
 *     &lt;enumeration value="APPLICANT2"/>
 *     &lt;enumeration value="PARTNER1"/>
 *     &lt;enumeration value="PARTNER2"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RoleType", namespace = "http://closemf.co.uk/id/enums")
@XmlEnum
public enum RoleType {

    @XmlEnumValue("APPLICANT1")
    APPLICANT_1("APPLICANT1"), @XmlEnumValue("APPLICANT2")
    APPLICANT_2("APPLICANT2"), @XmlEnumValue("PARTNER1")
    PARTNER_1("PARTNER1"), @XmlEnumValue("PARTNER2")
    PARTNER_2("PARTNER2");

    private final String value;


    RoleType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoleType fromValue(String v) {
        for (RoleType c : RoleType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
