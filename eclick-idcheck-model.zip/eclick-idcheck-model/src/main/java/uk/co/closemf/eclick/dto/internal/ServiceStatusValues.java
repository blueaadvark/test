package uk.co.closemf.eclick.dto.internal;

public enum ServiceStatusValues {

    PASS, FAIL, ERROR;

    public String value() {
        return name();
    }

    public static ServiceStatusValues fromValue(String v) {
        return valueOf(v);
    }

}
