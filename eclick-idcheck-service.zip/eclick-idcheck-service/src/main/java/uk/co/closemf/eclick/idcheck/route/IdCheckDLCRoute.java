package uk.co.closemf.eclick.idcheck.route;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class IdCheckDLCRoute extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        from("direct:DLC")
            .log(LoggingLevel.ERROR, "EClick ID Check Service encountered an error. Ref: ${header.ErrorReference}")
            .log(LoggingLevel.ERROR, System.lineSeparator() + "${body.stackTrace}");
            //.to("freemarker:template/ErrorEmailTemplate.ftl") // TODO: set up Email template
            //.bean("emailEntityBuilder")
    }
}
