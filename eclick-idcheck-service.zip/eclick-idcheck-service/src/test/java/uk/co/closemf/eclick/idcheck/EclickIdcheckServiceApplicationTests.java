package uk.co.closemf.eclick.idcheck;

import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

//@RunWith(CamelSpringBootRunner.class)
//@SpringBootTest
//@Configuration
@ComponentScan
//@EnableConfigurationProperties
public class EclickIdcheckServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
