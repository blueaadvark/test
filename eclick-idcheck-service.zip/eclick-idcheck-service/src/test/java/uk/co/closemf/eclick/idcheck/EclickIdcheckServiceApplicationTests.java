package uk.co.closemf.eclick.idcheck;

import org.junit.Test;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan
public class EclickIdcheckServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
