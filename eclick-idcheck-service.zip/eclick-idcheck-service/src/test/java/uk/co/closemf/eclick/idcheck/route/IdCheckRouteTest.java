package uk.co.closemf.eclick.idcheck.route;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.dto.internal.CustomerDetails;
import uk.co.closemf.eclick.idcheck.EclickIdcheckServiceApplicationTests;
import uk.co.closemf.eclick.idcheck.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = EclickIdcheckServiceApplicationTests.class)
@ActiveProfiles("test")
@UseAdviceWith(true)
public class IdCheckRouteTest extends CamelTestSupport{

	@Produce(uri = "activemq:testQueue")
	private ProducerTemplate template;
	
	@EndpointInject(uri = "mock:catchMessages")
	private MockEndpoint resultEndpoint;
	
	@EndpointInject(uri = "mock:catchErrors")
    private MockEndpoint errorEndpoint;
	
	@Value("classpath:idCheckRequest.xml")
    private Resource idCheckRequestXml;

	@Override
	public void setUp() throws Exception {
	    replaceRouteFromWith("activemq:testQueue-mock","activemq:testQueue");
	    super.setUp();
	}
/*	
	@Before
	public void mockEndpoints() throws Exception {
	    
	    AdviceWithRouteBuilder mockDestination = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http://localhost:8080/notSure")
                    .skipSendToOriginalEndpoint()
                    .to("mock:catchMessages");
            }
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockDestination);
 /*       
        AdviceWithRouteBuilder mockErrorDestination = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:DLC")
                    .skipSendToOriginalEndpoint()
                    .to("mock:catchErrors");
            }
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockErrorDestination);
      
        AdviceWithRouteBuilder mockAmq = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                replaceFromWith("activemq:testQueue-mock");
            }
        };
        context.getRouteDefinition("activemq:testQueue").adviceWith(context, mockAmq); 
  	} */
	

	@DirtiesContext
    @Test
    public void fromMqRouteTest() throws Exception {

    	String body = "<CustomerDetails/>";
    	String expectedBody = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" + System.lineSeparator() + "<CustomerDetails/>" + System.lineSeparator();
    	
    	//resultEndpoint.expectedBodiesReceived(expectedBody);
    	getMockEndpoint("mock:catchMessages").expectedBodiesReceived(expectedBody);
 
        template.sendBody("activemq:testQueue-mock", body);
 
        getMockEndpoint("mock:catchMessages").assertIsSatisfied();
        
   /*        
        resultEndpoint.expectedBodiesReceived(expectedBody);
 
        template.sendBody("activemq:testQueue", body);
 
        resultEndpoint.assertIsSatisfied();
        
     */   
    }
	
	@DirtiesContext
    @Test
    public void fromMqRouteWithCustomerDetailsTest() throws Exception {
	    
	    CustomerDetails expectedDetails = TestUtil.getTestDtoFromXML(CustomerDetails.class, idCheckRequestXml);

	    resultEndpoint.expectedMessageCount(1);
        
        String requestXmlString = TestUtil.getStringFromFile(idCheckRequestXml);
 
        template.sendBody("activemq:testQueue", requestXmlString);
        
        resultEndpoint.assertIsSatisfied();
        
        CustomerDetails receivedDetails = resultEndpoint.getExchanges().get(0).getIn().getBody(CustomerDetails.class);

        assertEquals(expectedDetails, receivedDetails);
    }
    

	@Override
	protected RouteBuilder createRouteBuilder() {
	    return new IdCheckRoute();
	}

}