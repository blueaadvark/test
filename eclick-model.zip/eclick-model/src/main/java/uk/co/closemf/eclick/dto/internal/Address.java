package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Java class for Address complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Address">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SequenceNo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Abodenumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BuildingNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BuildingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Street" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubStreet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Town" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="District" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StartMonth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="StartYear" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="EndMonth" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="EndYear" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Postcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AddressType" type="{http://closemf.co.uk/id/enums}AddressType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address", propOrder = { "sequenceNo", "abodenumber", "buildingNo", "buildingName", "street", "subStreet", "town",
        "district", "startMonth", "startYear", "endMonth", "endYear", "postcode", "addressType" })
public class Address implements Serializable{

	private static final long serialVersionUID = 3338429602801976768L;
	
	@XmlElement(name = "SequenceNo")
    protected int sequenceNo;
    @XmlElement(name = "Abodenumber")
    protected String abodenumber;
    @XmlElement(name = "BuildingNo")
    protected String buildingNo;
    @XmlElement(name = "BuildingName")
    protected String buildingName;
    @XmlElement(name = "Street")
    protected String street;
    @XmlElement(name = "SubStreet")
    protected String subStreet;
    @XmlElement(name = "Town")
    protected String town;
    @XmlElement(name = "District")
    protected String district;
    @XmlElement(name = "StartMonth")
    protected int startMonth;
    @XmlElement(name = "StartYear")
    protected int startYear;
    @XmlElement(name = "EndMonth", required = true, type = Integer.class, nillable = true)
    protected Integer endMonth;
    @XmlElement(name = "EndYear", required = true, type = Integer.class, nillable = true)
    protected Integer endYear;
    @XmlElement(name = "Postcode", required = true)
    protected String postcode;
    @XmlElement(name = "AddressType", required = true)
    protected AddressType addressType;


    /**
     * Gets the value of the sequenceNo property.
     * 
     */
    public int getSequenceNo() {
        return sequenceNo;
    }

    /**
     * Sets the value of the sequenceNo property.
     * 
     */
    public void setSequenceNo(int value) {
        this.sequenceNo = value;
    }

    /**
     * Gets the value of the abodenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAbodenumber() {
        return abodenumber;
    }

    /**
     * Sets the value of the abodenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAbodenumber(String value) {
        this.abodenumber = value;
    }

    /**
     * Gets the value of the buildingNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuildingNo() {
        return buildingNo;
    }

    /**
     * Sets the value of the buildingNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuildingNo(String value) {
        this.buildingNo = value;
    }

    /**
     * Gets the value of the buildingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuildingName() {
        return buildingName;
    }

    /**
     * Sets the value of the buildingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuildingName(String value) {
        this.buildingName = value;
    }

    /**
     * Gets the value of the street property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreet() {
        return street;
    }

    /**
     * Sets the value of the street property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreet(String value) {
        this.street = value;
    }

    /**
     * Gets the value of the subStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubStreet() {
        return subStreet;
    }

    /**
     * Sets the value of the subStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubStreet(String value) {
        this.subStreet = value;
    }

    /**
     * Gets the value of the town property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTown() {
        return town;
    }

    /**
     * Sets the value of the town property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTown(String value) {
        this.town = value;
    }

    /**
     * Gets the value of the district property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrict() {
        return district;
    }

    /**
     * Sets the value of the district property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrict(String value) {
        this.district = value;
    }

    /**
     * Gets the value of the startMonth property.
     * 
     */
    public int getStartMonth() {
        return startMonth;
    }

    /**
     * Sets the value of the startMonth property.
     * 
     */
    public void setStartMonth(int value) {
        this.startMonth = value;
    }

    /**
     * Gets the value of the startYear property.
     * 
     */
    public int getStartYear() {
        return startYear;
    }

    /**
     * Sets the value of the startYear property.
     * 
     */
    public void setStartYear(int value) {
        this.startYear = value;
    }

    /**
     * Gets the value of the endMonth property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEndMonth() {
        return endMonth;
    }

    /**
     * Sets the value of the endMonth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEndMonth(Integer value) {
        this.endMonth = value;
    }

    /**
     * Gets the value of the endYear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEndYear() {
        return endYear;
    }

    /**
     * Sets the value of the endYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEndYear(Integer value) {
        this.endYear = value;
    }

    /**
     * Gets the value of the postcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * Sets the value of the postcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostcode(String value) {
        this.postcode = value;
    }

    /**
     * Gets the value of the addressType property.
     * 
     * @return
     *     possible object is
     *     {@link AddressType }
     *     
     */
    public AddressType getAddressType() {
        return addressType;
    }

    /**
     * Sets the value of the addressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressType }
     *     
     */
    public void setAddressType(AddressType value) {
        this.addressType = value;
    }

    @Override
    public int hashCode() {  	
    	return HashCodeBuilder.reflectionHashCode(this);	
    	
    }

    @Override
    public boolean equals(Object obj) {	
    	return EqualsBuilder.reflectionEquals(this, obj);
    }

    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }

}
