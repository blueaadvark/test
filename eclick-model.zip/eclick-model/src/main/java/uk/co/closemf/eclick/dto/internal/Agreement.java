package uk.co.closemf.eclick.dto.internal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Agreement", propOrder = {
    "unsignedAgreementDocument",
    "agreementType",
    "signatureCaptureAgreementDocument"
})

@XmlRootElement(name="Agreement")
public class Agreement {

    public static final String AGREEMENT_TYPE = "CLOSEMOTOR_DEFAULT";

    @XmlElement(name = "UnsignedAgreementDocument")
    protected String unsignedAgreementDocument;
    @XmlElement(name = "AgreementType")
    protected String agreementType = AGREEMENT_TYPE;
    
    @XmlElement(name = "AgreementType", required = false)
    private byte[] signatureCaptureAgreementDocument;


    public Agreement() {
    }

    public Agreement(String value) {
        setUnsignedAgreementDocument(value);
    }

    /**
     * Gets the value of the unsignedAgreementDocument property.
     * 
     * @return possible object is byte[]
     */
    public String getUnsignedAgreementDocument() {
        return unsignedAgreementDocument;
    }

    /**
     * Sets the value of the unsignedAgreementDocument property.
     * 
     * @param value
     *            allowed object is byte[]
     */
    public void setUnsignedAgreementDocument(String value) {
        this.unsignedAgreementDocument = value;
    }

    /**
     * Gets the value of the agreementType property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getAgreementType() {
        return agreementType;
    }

    /**
     * Sets the value of the agreementType property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAgreementType(String value) {
        this.agreementType = value;
    }

    @Override
    public String toString() {
        return "Agreement [agreementType=" + agreementType + "]";
    }

    public void setSignatureCaptureAgreementDocument(byte[] agreement) {
        this.signatureCaptureAgreementDocument = agreement;
    }

    public byte[] getSignatureCaptureAgreementDocument() {
        return signatureCaptureAgreementDocument;
    }

}
