package uk.co.closemf.eclick.dto.internal;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AgreementTransactionRequest", propOrder = {
    "proposalID",
    "docTransactionID",
    "customerDetails",
    "agreement",
    "placeholders",
    "transactionToken",
    "businessName",
    "callbackEnv",
    "proofsRequired"
})

@XmlRootElement(name="AgreementTransactionRequest")
public class AgreementTransactionRequest {
   
    @XmlElement(name = "ProposalID")
    protected String proposalID;
    @XmlElement(name = "DocTransactionID")
    protected String docTransactionID;
    @XmlElement(name = "CustomerDetails")
    protected List<CustomerDetails> customerDetails;
    @XmlElement(name = "Agreement")
    protected Agreement agreement;
    @XmlElement(name = "Placeholders")
    protected List<String> placeholders;
    @XmlElement(name = "TransactionToken", required = false)
    protected TransactionToken transactionToken;
    @XmlElement(name = "BusinessName")
    protected String businessName;
    @XmlElement(name = "CallbackEnv", required = false)
    private String callbackEnv;
    @XmlElement(name = "ProofsRequired")
    private Boolean proofsRequired;

    /**
     * Gets the value of the proposalId property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getProposalID() {
        return proposalID;
    }

    /**
     * Sets the value of the proposalId property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setProposalID(String value) {
        this.proposalID = value;
    }

    /**
     * Gets the value of the customerDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the customerDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getCustomerDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerDetails }
     * 
     * 
     */
    public List<CustomerDetails> getCustomerDetails() {
        if (customerDetails == null) {
            customerDetails = new ArrayList<CustomerDetails>();
        }
        return this.customerDetails;
    }

    /**
     * Gets the value of the eSignatureDetails property.
     * 
     * @return possible object is {@link Agreement }
     * 
     */
    public Agreement getAgreement() {
        return agreement;
    }

    /**
     * Sets the value of the eSignatureDetails property.
     * 
     * @param value
     *            allowed object is {@link Agreement }
     * 
     */
    public void setAgreement(Agreement value) {
        this.agreement = value;
    }

    public List<String> getPlaceholders() {
        if (placeholders == null) {
            placeholders = new ArrayList<String>();
        }
        return placeholders;
    }

    /**
     * Gets the value of the transactionToken property.
     * 
     * @return possible object is {@link TransactionToken }
     * 
     */
    public TransactionToken getTransactionToken() {
        return transactionToken;
    }

    /**
     * Sets the value of the transactionToken property.
     * 
     * @param value
     *            allowed object is {@link TransactionToken }
     * 
     */
    public void setTransactionToken(TransactionToken value) {
        this.transactionToken = value;
    }

    public String getDocTransactionID() {
        return docTransactionID;
    }

    public void setDocTransactionID(String docTransactionID) {
        this.docTransactionID = docTransactionID;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String name) {
        this.businessName = name;
    }

    public void setCallback(String env) {
        this.callbackEnv = env;
    }

    public String getCallback() {
        return callbackEnv;
    }

    public Boolean isProofsRequired() {
        return proofsRequired;
    }

    public void setProofsRequired(Boolean proofsRequired) {
        this.proofsRequired = proofsRequired;
    }
    
    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {      
        return ToStringBuilder.reflectionToString(this);
        
    }

}
