package uk.co.closemf.eclick.dto.internal;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AgreementTransactionResponse", propOrder = {
    "proposalID",
    "docTransactionID",
    "unSignedAgreementDocStoreId",
    "header",
    "serviceStatus",
    "signatureUrl",
    "atFaults",
    "idCheckResponse"
    
})

@XmlRootElement(name="AgreementTransactionResponse")
public class AgreementTransactionResponse {

    @XmlElement(name = "ProposalID")
    protected String proposalID;
    @XmlElement(name = "DocTransactionID")
    protected String docTransactionID;
    @XmlElement(name = "UnSignedAgreementDocStoreId", required = false)
    protected Long unSignedAgreementDocStoreId;
    @XmlElement(name = "Header")
    protected ServiceResponseHeader header;
    @XmlElement(name = "ServiceStatus")
    protected ServiceStatusValues serviceStatus;
    @XmlElement(name = "SignatureUrl")
    protected String signatureUrl;
    @XmlElement(name = "IDCheckResponse")
    protected IDCheckResponse idCheckResponse;
    @XmlElement(name = "Fault")
    protected List<Fault> atFaults = new ArrayList<>();


    public AgreementTransactionResponse() {
    }

    public AgreementTransactionResponse(List<Fault> faults) {
        getFault().addAll(faults);
        setServiceStatus(ServiceStatusValues.ERROR);
    }

    public AgreementTransactionResponse(List<Fault> faults, Date timestamp) {
        this(faults);
        header = new ServiceResponseHeader(timestamp);
    }

    public String getProposalID() {
        return proposalID;
    }

    public void setProposalID(String proposalID) {
        this.proposalID = proposalID;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return possible object is {@link ServiceResponseHeader }
     * 
     */
    public ServiceResponseHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *            allowed object is {@link ServiceResponseHeader }
     * 
     */
    public void setHeader(ServiceResponseHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the serviceStatus property.
     * 
     * @return possible object is {@link ServiceStatusValues }
     * 
     */
    public ServiceStatusValues getServiceStatus() {
        return serviceStatus;
    }

    /**
     * Sets the value of the serviceStatus property.
     * 
     * @param value
     *            allowed object is {@link ServiceStatusValues }
     * 
     */
    public void setServiceStatus(ServiceStatusValues value) {
        this.serviceStatus = value;
    }

    public String getSignatureUrl() {
        return signatureUrl;
    }

    public void setSignatureUrl(String signatureUrl) {
        this.signatureUrl = signatureUrl;
    }

    /**
     * Gets the value of the idCheckResponse property.
     * 
     * @return possible object is {@link IDCheckResponse }
     * 
     */
    public IDCheckResponse getIDCheckResponse() {
        return idCheckResponse;
    }

    /**
     * Sets the value of the idCheckResponse property.
     * 
     * @param value
     *            allowed object is {@link IDCheckResponse }
     * 
     */
    public void setIDCheckResponse(IDCheckResponse value) {
        this.idCheckResponse = value;
    }

    /**
     * Gets the value of the fault property. To add a new item, do as follows:
     * 
     * <pre>
     * getFault().add(newItem);
     * </pre>
     * 
     * Objects of the following type(s) are allowed in the list {@link Fault }
     * 
     * 
     */
    public List<Fault> getFault() {
        if (atFaults == null) {
            atFaults = new ArrayList<>();
        }
        return this.atFaults;
    }

    public String getDocTransactionID() {
        return docTransactionID;
    }

    public void setDocTransactionID(String docTransactionID) {
        this.docTransactionID = docTransactionID;
    }

    /**
     * @param docStoreId
     */
    public void setUnSignedAgreementDocStoreId(Long docStoreId) {
        this.unSignedAgreementDocStoreId = docStoreId;
    }

    public Long getUnSignedAgreementDocStoreId() {
        return unSignedAgreementDocStoreId;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {      
        return ToStringBuilder.reflectionToString(this);
        
    }
}
