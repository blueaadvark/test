package uk.co.closemf.eclick.dto.internal;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class CallBackParameters implements Serializable{

	private static final long serialVersionUID = -4795678192879151115L;
	private String status;
    private String partnerVerificationToken;
    private String iocsTransactionId;
    private String transactionTime;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPartnerVerificationToken() {
        return partnerVerificationToken;
    }

    public void setPartnerVerificationToken(String partnerVerificationToken) {
        this.partnerVerificationToken = partnerVerificationToken;
    }

    public String getIocsTransactionId() {
        return iocsTransactionId;
    }

    public void setIocsTransactionId(String iocsTransactionId) {
        this.iocsTransactionId = iocsTransactionId;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }
    
    @Override
    public int hashCode() {
    	return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
    	return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {    	
    	return ToStringBuilder.reflectionToString(this);
        
    }
}
