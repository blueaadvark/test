package uk.co.closemf.eclick.dto.internal;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for TelephoneType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TelephoneType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Home"/>
 *     &lt;enumeration value="Mobile"/>
 *     &lt;enumeration value="Work"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TelephoneType", namespace = "http://closemf.co.uk/id/enums")
@XmlEnum
public enum TelephoneType {

    @XmlEnumValue("Home")
    HOME("Home"), @XmlEnumValue("Mobile")
    MOBILE("Mobile"), @XmlEnumValue("Work")
    WORK("Work"), @XmlEnumValue("Other")
    OTHER("Other");

    private final String value;


    TelephoneType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TelephoneType fromValue(String v) {
        for (TelephoneType c : TelephoneType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
