/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.dto.internal;

/**
 * @author tasmith
 *
 */
public class UnknownNotification extends DocumentNotification {

	private static final long serialVersionUID = -257523903817234709L;

}
