package uk.co.closemf.eclick.transaction.route;

import static org.apache.camel.component.jms.JmsComponent.jmsComponentAutoAcknowledge;

import javax.jms.ConnectionFactory;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpComponent;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;
import uk.co.closemf.eclick.transaction.test.util.CamelJmsTestHelper;
import uk.co.closemf.eclick.transaction.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = {EclickTransactionServiceApplication.class, TransactionRoute.class, TransactionDLCRoute.class})
@ActiveProfiles("ci")
@EnableAutoConfiguration
@UseAdviceWith(true)
@ComponentScan
public class TransactionDLCRouteIntTest extends CamelTestSupport{
    
    @Autowired
    private TransactionRoute transactionRoute;
    
    @Autowired
    private TransactionDLCRoute transactionDLCRoute;

    @Produce(uri = "activemq:testQueue")
    private ProducerTemplate template;
    
    @EndpointInject(uri = "mock:catchMessages")
    private MockEndpoint resultEndpoint;
    
    @EndpointInject(uri = "mock:mqResponse")
    private MockEndpoint mqResponseEndpoint;
    
    @EndpointInject(uri = "mock:errorMessages")
    private MockEndpoint errorEndpoint;
    
    @Value("classpath:agreementTransactionRequest.xml")
    private Resource agreementTransactionRequestXml;
        
    @Value("classpath:agreementTransactionResponse.xml")
    private Resource agreementTransactionResponseXml;
    

    @Before
    public void mockEndpoints() throws Exception {
        
        context.addRoutes(transactionDLCRoute);

        AdviceWithRouteBuilder mockDestination = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http://localhost:8080/notSure")
                    .skipSendToOriginalEndpoint()
                    .to("mock:catchMessages");
                
                weaveById("addSignatureBoxProcessor").remove(); 
            }
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockDestination);
        
        AdviceWithRouteBuilder mockMqResponse = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("activemq:response")
                    .skipSendToOriginalEndpoint()
                    .to("mock:mqResponse");     
                
                weaveById("storeDocumentStateProcessor").remove(); 
            }
            
            
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockMqResponse);
    
    AdviceWithRouteBuilder mockErrorResponse = new AdviceWithRouteBuilder() {

        @Override
        public void configure() throws Exception {
            interceptSendToEndpoint("direct:errorQueue")
                .skipSendToOriginalEndpoint()
                .to("mock:errorMessages");         
        }
        
    };
    context.getRouteDefinitions().get(0)
        .adviceWith(context, mockErrorResponse);
    }

    protected CamelContext createCamelContext() throws Exception {
        CamelContext camelContext = super.createCamelContext();

        ConnectionFactory connectionFactory = CamelJmsTestHelper.createConnectionFactory();
        camelContext.addComponent("activemq", jmsComponentAutoAcknowledge(connectionFactory));   
        
        return camelContext;
    }
  
    @DirtiesContext
    @Test
    public void dlcTest() throws Exception {
        
        errorEndpoint.setExpectedMessageCount(1);
        String responseXmlString = TestUtil.getStringFromFile(agreementTransactionResponseXml);
        template.sendBody(responseXmlString);
        errorEndpoint.assertIsSatisfied();
        
        AgreementTransactionResponse expectedDetails = TestUtil.getTestDtoFromXML(AgreementTransactionResponse.class, agreementTransactionResponseXml);
 
        template.sendBody(responseXmlString);
        
        errorEndpoint.assertIsSatisfied();
        
        //AgreementTransactionRequest receivedDetails = resultEndpoint.getExchanges().get(0).getIn().getBody(AgreementTransactionRequest.class);

        //Diff diff = DiffBuilder.compare(expectedDetails).withTest(receivedDetails).build();
        //assertFalse(diff.hasDifferences());

    }
     
    @Override
    protected RouteBuilder createRouteBuilder() throws Exception {
        HttpComponent httpComponent = new HttpComponent();
        context().addComponent("http", httpComponent);
        context().addRoutes(transactionRoute);
        return transactionDLCRoute;
    }

}