package uk.co.closemf.eclick.transaction.route;

import static org.apache.camel.component.jms.JmsComponent.jmsComponentAutoAcknowledge;

import javax.jms.ConnectionFactory;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpComponent;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;
import uk.co.closemf.eclick.transaction.test.util.CamelJmsTestHelper;
import uk.co.closemf.eclick.transaction.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = {EclickTransactionServiceApplication.class, TransactionRoute.class})
@ActiveProfiles("ci")
@EnableAutoConfiguration
@UseAdviceWith(true)
@ComponentScan
public class TransactionRouteIntTest extends CamelTestSupport{
    
    @Autowired
    private TransactionRoute transactionRoute;

    @Produce(uri = "activemq:testQueue")
    private ProducerTemplate template;
    
    @EndpointInject(uri = "mock:catchMessages")
    private MockEndpoint resultEndpoint;
    
    @EndpointInject(uri = "mock:mqResponse")
    private MockEndpoint mqResponseEndpoint;
    
    @Value("classpath:agreementTransactionRequest.xml")
    private Resource agreementTransactionRequestXml;
    
    @Value("classpath:eDocTrans.xml")
    private Resource unsignedAgreementTransactionRequestXml;
    
    @Value("classpath:eDocTransResponse.xml")
    private Resource unsignedAgreementTransactionResponseXml;
    
    @Value("classpath:agreementTransactionResponse.xml")
    private Resource agreementTransactionResponseXml;
    

    @Before
    public void mockEndpoints() throws Exception {

        AdviceWithRouteBuilder mockDestination = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http://localhost:8080/notSure")
                    .skipSendToOriginalEndpoint()
                    .to("mock:catchMessages");
                
                weaveById("addSignatureBoxProcessor").remove(); 
            }
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockDestination);
        
        AdviceWithRouteBuilder mockMqResponse = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("activemq:response")
                    .skipSendToOriginalEndpoint()
                    .to("mock:mqResponse");     
                
                weaveById("storeDocumentStateProcessor").remove(); 
            }
            
            
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockMqResponse);
    }

    protected CamelContext createCamelContext() throws Exception {
        CamelContext camelContext = super.createCamelContext();

        ConnectionFactory connectionFactory = CamelJmsTestHelper.createConnectionFactory();
        camelContext.addComponent("activemq", jmsComponentAutoAcknowledge(connectionFactory));   
        
        return camelContext;
    }
  
    @DirtiesContext
    @Test
    public void fromMqRouteTest() throws Exception {
        
        AgreementTransactionRequest expectedDetails = TestUtil.getTestDtoFromXML(AgreementTransactionRequest.class, agreementTransactionRequestXml);

        resultEndpoint.expectedMessageCount(1);
        
        String requestXmlString = TestUtil.getStringFromFile(agreementTransactionRequestXml);
        
        resultEndpoint.expectedMessageCount(1);
 
        template.sendBody(requestXmlString);
        
        resultEndpoint.assertIsSatisfied();
        
        AgreementTransactionRequest receivedDetails = resultEndpoint.getExchanges().get(0).getIn().getBody(AgreementTransactionRequest.class);

        Diff diff = DiffBuilder.compare(expectedDetails).withTest(receivedDetails).build();
        assertFalse(diff.hasDifferences());

    }
     
    @Override
    protected RouteBuilder createRouteBuilder() throws Exception {
        HttpComponent httpComponent = new HttpComponent();
        context().addComponent("http", httpComponent);
        
        return transactionRoute;
    }

}