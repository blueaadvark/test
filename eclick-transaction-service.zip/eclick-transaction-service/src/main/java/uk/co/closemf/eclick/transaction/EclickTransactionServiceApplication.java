package uk.co.closemf.eclick.transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import uk.co.cmf.docs.dao.DocStoreDao;

@EnableAutoConfiguration
@SpringBootApplication
@ComponentScan
public class EclickTransactionServiceApplication {
    
    @Autowired
    DocStoreDao docStoreDao;

	public static void main(String[] args) {
		SpringApplication.run(EclickTransactionServiceApplication.class, args);
	}
	
	@Bean
    public DocStoreDao docStoreDao() {
        return docStoreDao;
    }

	
}
