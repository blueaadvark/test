package uk.co.closemf.eclick.transaction.bean;

/*
 * Code lifted from IOCS
 */
public class PlaceholderCoordinates implements Comparable<PlaceholderCoordinates> {

    private int pageNo;
    private TextCoordinates td;
    private String placeholder;


    public PlaceholderCoordinates(int pageNo) {
        this.pageNo = pageNo;
    }

    public PlaceholderCoordinates(int pageNo, TextCoordinates td) {
        this(pageNo);
        this.td = td;
    }

    public PlaceholderCoordinates(String placeholder, int pageNo, TextCoordinates td) {
        this(pageNo, td);
        this.placeholder = placeholder;
    }

    public int getPageNo() {
        return pageNo;
    }

    public TextCoordinates getTd() {
        return td;
    }

    public String getPlaceholder() {
        return placeholder;
    }

    @Override
    public String toString() {
        return "PlaceholderCoordinates [pageNo=" + pageNo + ", td=" + td + ", placeholder=" + placeholder + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + pageNo;
        result = prime * result + ((placeholder == null) ? 0 : placeholder.hashCode());
        result = prime * result + ((td == null) ? 0 : td.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PlaceholderCoordinates other = (PlaceholderCoordinates) obj;
        if (pageNo != other.pageNo)
            return false;
        if (placeholder == null) {
            if (other.placeholder != null)
                return false;
        } else if (!placeholder.equals(other.placeholder))
            return false;
        if (td == null) {
            if (other.td != null)
                return false;
        } else if (!td.equals(other.td))
            return false;
        return true;
    }

    @Override
    public int compareTo(PlaceholderCoordinates other) {
        int page = this.pageNo - other.getPageNo();
        if (page == 0) {
            return td.compareTo(other.getTd());
        }
        return page;
    }
}
