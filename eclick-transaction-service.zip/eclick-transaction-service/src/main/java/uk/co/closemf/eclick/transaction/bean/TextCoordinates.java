/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.transaction.bean;

/**
 * @author tasmith
 *
 *
 * Code lifted from IOCS
 */
public class TextCoordinates {

    private final String op;
    private double y;
    private double x;


    public TextCoordinates(String op) {
        super();
        this.op = op;
    }

    public void setY(double coord) {
        this.y = coord;
    }

    public void setX(double coord) {
        this.x = coord;
    }

    public String getOp() {
        return op;
    }

    public double getY() {
        return y;
    }

    public double getX() {
        return x;
    }

    @Override
    public String toString() {
        return String.format("TextCoordinates [op=%s, x=%.2f, y=%.2f]", op, x, y);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((op == null) ? 0 : op.hashCode());
        long temp;
        temp = Double.doubleToLongBits(x);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(y);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TextCoordinates other = (TextCoordinates) obj;
        if (op == null) {
            if (other.op != null)
                return false;
        } else if (!op.equals(other.op))
            return false;
        if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
            return false;
        if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
            return false;
        return true;
    }

    public int compareTo(TextCoordinates other) {
        int x = Double.compare(this.x, other.getX());
        if (x == 0) {
            int y = Double.compare(this.y, other.getY());
            return y;
        }
        return x;
    }

}
