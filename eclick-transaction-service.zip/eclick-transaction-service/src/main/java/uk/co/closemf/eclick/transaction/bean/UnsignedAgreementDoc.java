/*
 *  ____  _   _ ____
 * /  _ \| \ / |  __|
 * | |_--| |-| |  _|
 * \____/|_| |_|_|
 * ~~~~~~~~~~~~~~~~~~
 *
 * ================================================================
 *
 * Copyright (c) 2013 Close Motor Finance Ltd, All rights reserved.
 *
 * ================================================================
 */
package uk.co.closemf.eclick.transaction.bean;

import uk.co.cmf.docs.MultiSourceDocument;
import uk.co.cmf.docs.SourceSystemKey;

import java.util.ArrayList;
import java.util.List;

import static uk.co.cmf.docs.SourceSystemKey.DOC_STORE_DFLT_SOURCE_ID;
import static uk.co.cmf.docs.SourceSystemKey.DOC_STORE_PROPOSAL_KEY_TYPE;

/**
 * @author tasmith
 * 
 * Code lifted from IOCS
 */
public class UnsignedAgreementDoc extends MultiSourceDocument {

    public static final String DOC_STORE_DFLT_CATEGORY = "UNDERWRITING";
    public static final String DOC_STORE_DFLT_TYPE = "UNSIGNED AGREEMENT";
    public static final String DOC_STORE_FILENAME_FORMAT = "Proposal %s Unsigned Agreement.pdf";


    /**
     * Creates an unsigned agreement document
     * 
     * @param encodedDoc
     *            the document body
     * @param proposalID
     *            the proposal id
     */
    public UnsignedAgreementDoc(String encodedDoc, String proposalID) {
        super(getSystemSourceKeys(proposalID), encodedDoc, DOC_STORE_PDF_FORMAT, getFilename(proposalID));
        setCategory(DOC_STORE_DFLT_CATEGORY);
        setDocType(DOC_STORE_DFLT_TYPE);
    }

    public static String getFilename(String proposalID) {
        return String.format(DOC_STORE_FILENAME_FORMAT, proposalID);
    }

    /**
     * Builds a {@link SourceSystemKey} for this document using a default system
     * id and a key/value pair holding the proposal id
     * 
     * @param proposalId
     * @return
     */
    private static List<SourceSystemKey> getSystemSourceKeys(String proposalId) {
        SourceSystemKey ssk = new SourceSystemKey(DOC_STORE_DFLT_SOURCE_ID, DOC_STORE_PROPOSAL_KEY_TYPE, proposalId);
        List<SourceSystemKey> keys = new ArrayList<>();
        keys.add(ssk);
        return keys;
    }

}
