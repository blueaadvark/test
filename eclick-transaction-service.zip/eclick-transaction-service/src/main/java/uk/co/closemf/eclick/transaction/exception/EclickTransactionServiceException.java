package uk.co.closemf.eclick.transaction.exception;

import java.util.Date;
import java.util.List;

import uk.co.closemf.eclick.dto.internal.Fault;

public class EclickTransactionServiceException extends RuntimeException {

    private static final long serialVersionUID = -3087576209641803369L;
    @SuppressWarnings("unused")
    private List<Fault> faults;
    @SuppressWarnings("unused")
    private Date timestamp;
    

    public EclickTransactionServiceException() {
    }
    
    public EclickTransactionServiceException(String message) {
        super(message);
    }

    public EclickTransactionServiceException(String message, Exception e) {
        super(message, e);
    }
    
    public EclickTransactionServiceException(List<Fault> faults) {
        super("Fault List");
        this.faults = faults;
    }

    public EclickTransactionServiceException(List<Fault> faults, Date timestamp) {
        this(faults);
        this.timestamp = timestamp;
    }
}
