package uk.co.closemf.eclick.transaction.pdf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

/**
 * Switch pdf to decompressed state.
 * 
 * @author tasmith
 * 
 *
 * Code lifted from IOCS
 */
public class Decompressor {

    private static final Logger LOG = LoggerFactory.getLogger(Decompressor.class);


    public static byte[] decompressPdf(byte[] src) throws DocumentException, IOException {
        LOG.info("Compressed PDF Size:" + src.length);
        PdfReader reader = null;
        PdfStamper stamper = null;
        ByteArrayOutputStream dest = new ByteArrayOutputStream();

        try {
            reader = new PdfReader(src);
            stamper = new PdfStamper(reader, dest);
            stamper.getWriter().setCloseStream(false);
            Document.compress = false;

            int total = reader.getNumberOfPages() + 1;
            for (int i = 1; i < total; i++) {
                reader.setPageContent(i, reader.getPageContent(i));
            }
        } catch (IOException|DocumentException e) {
            LOG.error("Decompressed PDF Error: " + e);
            throw new RuntimeException(e);
        } finally {
            Document.compress = true;
            // Close the reader
            if (reader != null) {
                reader.close();
            }
            // Close the stamper
            if (stamper != null) {
                stamper.close();
            }
        }
        LOG.info("Decompressed PDF Size:" + dest.toByteArray().length);
        return dest.toByteArray();
    }

}
