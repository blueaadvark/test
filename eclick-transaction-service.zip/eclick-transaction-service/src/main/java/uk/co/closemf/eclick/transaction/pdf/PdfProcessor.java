/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.transaction.pdf;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.DocumentException;

import uk.co.closemf.eclick.transaction.bean.PlaceholderCoordinates;

/*
 * Code lifted from IOCS
 */
public class PdfProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(PdfProcessor.class);

    public static byte[] addSignatureCapture(byte[] doc, List<String> placeholders) {

        try {
            LOG.debug("Signature Forms process started with: " + placeholders);

            List<PlaceholderCoordinates> coords = new uk.co.closemf.eclick.transaction.pdf.pdfbox.AgreementForms().searchForCoords(doc, placeholders);

            byte[] agreementWithSignatureForms = decompress(new uk.co.closemf.eclick.transaction.pdf.itext.AgreementForms().addSignatureFields(doc, coords));

            LOG.debug("Signature Forms Completed");

            return agreementWithSignatureForms;
        } catch (Exception e) {
            throw new RuntimeException("Signature placeholder processing failed", e);
        }
    }

    private static byte[] decompress(byte[] src) throws DocumentException, IOException {
        return Decompressor.decompressPdf(src);
  
    }

}
