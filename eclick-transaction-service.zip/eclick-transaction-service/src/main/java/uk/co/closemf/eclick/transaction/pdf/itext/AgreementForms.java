package uk.co.closemf.eclick.transaction.pdf.itext;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfAppearance;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import uk.co.closemf.eclick.transaction.bean.PlaceholderCoordinates;

/*
 * Code lifted from IOCS
 */

public class AgreementForms {

    private static final Logger LOG = LoggerFactory.getLogger(AgreementForms.class);

    private static final int FORM_FIELD_Y_COORD_ADJUSTMENT = 14;
    private static final int formWidth = 190;
    private static final int labelWidth = 10;
    private static final int cellHeight = 34;
    private static final boolean addLabel = false;

    // Reduce by 30 units for the dealer signature box
    private static final int dealerSignatureWidthReducer = 30;

    public byte[] addSignatureFields(byte[] agreement, List<PlaceholderCoordinates> placeholders) throws DocumentException,
            IOException {
        PdfReader reader = null;
        PdfStamper stamper = null;
        List<FormField> fields = new ArrayList<>(placeholders.size());
        ByteArrayOutputStream agreementWithSignatureForms = new ByteArrayOutputStream();

        LOG.info("Adding Forms at coordinates [" + placeholders + "]");

        try {
            // Original doc.
            reader = new PdfReader(agreement);

            // Create a stamper
            stamper = new PdfStamper(reader, agreementWithSignatureForms);
            stamper.getWriter().setCloseStream(false);

            int n = reader.getNumberOfPages();

            for (PlaceholderCoordinates placeholder : placeholders) {

                if (placeholder.getPageNo() <= n) {
                    fields.add(new FormField(placeholder.getPlaceholder(), placeholder.getPlaceholder(), placeholder.getPageNo(),
                            placeholder.getTd().getX(), placeholder.getTd().getY()));
                }
            }
            for (FormField field : fields) {
              
                int llx = field.getX();
                int lly = field.getY() + FORM_FIELD_Y_COORD_ADJUSTMENT;

                int urx = llx + formWidth;
                int ury = lly - cellHeight;

                /*
                 * The DEALER_SIGNATURE_LOCATOR fields needs to have a less than standard width
                 * as expressed in the dealerSignatureWidthReducer. To make the width the same for all
                 * signature fields set the dealerSignatureWidthReducer = 0.
                 */

                if (field.getLabel().startsWith("DEALER_SIGNATURE_LOCATOR")) {
                    if (dealerSignatureWidthReducer > 0) {
                        LOG.info("Reducing " + field.getLabel() + " width by [" + dealerSignatureWidthReducer + "] units");
                        urx = llx + formWidth - dealerSignatureWidthReducer;
                    }
                }

                PdfFormField formField = PdfFormField.createSignature(stamper.getWriter());
                formField.setWidget(new Rectangle(llx, lly, urx, ury), PdfAnnotation.APPEARANCE_NORMAL);
                formField.setFieldName(field.getName());
                formField.setFlags(PdfAnnotation.FLAGS_PRINT);
                formField.setPage();

                PdfAppearance tp = PdfAppearance.createAppearance(stamper.getWriter(), 72, 48);
                tp.rectangle(0.5f, 0.5f, 71.5f, 47.5f);
                tp.stroke();

                stamper.addAnnotation(formField, field.getPage());
                LOG.info("Created Form Field: " + field);
            }
        } catch (IOException|DocumentException e) {
            LOG.error(e.toString());
            throw new RuntimeException(e);
        } finally {
            // Close the reader
            if (reader != null) {
                reader.close();
            }
            // Close the stamper
            if (stamper != null) {
                stamper.close();
            }
        }
        return agreementWithSignatureForms.toByteArray();
    }

}
