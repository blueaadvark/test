/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.transaction.pdf.itext;

/**
 * @author tasmith
 *
 */
public class FormField {

    private String name;
    private int page;
    private double xCoord;
    private double yCoord;
    private String label;


    public FormField(String name, int page, double d, double e) {
        this.name = name;
        this.page = page;
        this.xCoord = d;
        this.yCoord = e;
    }

    public FormField(String label, String name, int page, double d, double e) {
        this(name, page, d, e);
        this.label = label;
    }

    public String getName() {
        return name;
    }

    public int getPage() {
        return page;
    }

    public double getXCoord() {
        return xCoord;
    }

    public double getYCoord() {
        return yCoord;
    }

    public int getX() {
        return (int) Math.round(xCoord);
    }

    public int getY() {
        return (int) Math.round(yCoord);
    }

    public String getLabel() {
        return label;
    }

    @Override
    public String toString() {
        return "FormField [name=" + name + ", page=" + page + ", xCoord=" + xCoord + ", yCoord=" + yCoord + ", label=" + label
                + "]";
    }

}
