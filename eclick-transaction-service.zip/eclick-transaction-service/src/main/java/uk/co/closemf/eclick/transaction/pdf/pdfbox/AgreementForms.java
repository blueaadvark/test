package uk.co.closemf.eclick.transaction.pdf.pdfbox;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSFloat;
import org.apache.pdfbox.cos.COSInteger;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.util.PDFOperator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import uk.co.closemf.eclick.transaction.bean.PlaceholderCoordinates;
import uk.co.closemf.eclick.transaction.bean.TextCoordinates;

/*
 * Code lifted from IOCS
 */

public class AgreementForms {

    private static final Logger LOG = LoggerFactory.getLogger(AgreementForms.class);


    public List<PlaceholderCoordinates> searchForCoords(byte[] agreement, List<String> placeholders) throws IOException {
        Assert.notEmpty(placeholders, "No placeholders supplied for agreement signatures!");

        List<PlaceholderCoordinates> coords = new ArrayList<PlaceholderCoordinates>();
        PDDocument doc = null;

        try {
            // Read in the agreement PDF.
            doc = PDDocument.load(new ByteArrayInputStream(agreement));

            // Process each page.
            @SuppressWarnings("unchecked")
            List<PDPage> pages = doc.getDocumentCatalog().getAllPages();
            for (int pageNo = 0; pageNo < pages.size(); pageNo++) {

                coords.addAll(processPage(placeholders, (PDPage) pages.get(pageNo), pageNo));

            }
            LOG.info("Placeholders @ " + coords);
            return coords;
        } catch (Exception e) {
            LOG.error(e.toString());
            throw new RuntimeException(e);
        } finally {
            if (doc != null) {
                doc.close();
            }
        }
    }

    private List<? extends PlaceholderCoordinates> processPage(List<String> placeholders, PDPage page, int pageNo) {
        TextArea beginText = null;
        List<PlaceholderCoordinates> coords = new ArrayList<PlaceholderCoordinates>();
        TextCoordinates currentTd = null;
        LOG.debug("Processing Agreement page: " + pageNo);

        // Load page directives.
        List<Object> tokens = parsePdfTokens(page);
        for (int tokenPos = 0; tokenPos < tokens.size(); tokenPos++) {
            Object nextToken = tokens.get(tokenPos);

            if (nextToken instanceof PDFOperator) {
                PDFOperator op = (PDFOperator) nextToken;
                LOG.debug("Operator: " + op);

                // Start a Text area
                beginText = beginText(op, beginText);
                if (beginText != null) {
                    // Record coordinate directives as we pass by.
                    TextCoordinates td = getTextCoords(tokens, tokenPos, op);
                    currentTd = td == null ? currentTd : td;

                    List<String> strings = getTextStrings(tokens, tokenPos, op);

                    if (strings.size() > 0 && currentTd != null) {
                        // Coordinate relative to text area?
                        currentTd = beginText.addCoord(currentTd);
                        // If we have string directive, look for placeholder string
                        for (String placeholder : placeholders) {
                            if (strings.contains(placeholder)) {

                                // Save page and x,y coordinates of placeholder.
                                PlaceholderCoordinates coord = new PlaceholderCoordinates(placeholder, pageNo + 1, currentTd);
                                coords.add(coord);
                                LOG.debug(coord.toString());
                            }
                        }
                    }
                }
            }
        }
        return coords;
    }

    private List<Object> parsePdfTokens(PDPage page) {
        try {
            PDStream contents = page.getContents();

            PDFStreamParser parser = new PDFStreamParser(contents.getStream());
            parser.parse();
            List<Object> tokens = parser.getTokens();

            return tokens;
        } catch (IOException e) {
            LOG.error(e.toString());
            throw new RuntimeException(e);
        }
    }

    private List<String> getTextStrings(List<Object> tokens, int tokenPos, PDFOperator op) {
        List<String> strings = new ArrayList<>();

        if ("tj".equalsIgnoreCase(op.getOperation())) {
            // Tj takes one operand and that is the string or array, reverse to
            // get it...
            Object operand = tokens.get(tokenPos - 1);
            LOG.debug("Text String Operation: " + op + " (" + operand + ")");

            if ("Tj".equals(op.getOperation())) {
                strings.add(getTextString(operand));
            } else if ("TJ".equals(op.getOperation())) {
                strings.addAll(getTextStringFromArray(operand));
            }
        }
        return strings;
    }

    private Collection<? extends String> getTextStringFromArray(Object token) {
        List<String> strings = new ArrayList<>();

        if (token instanceof COSArray) {
            COSArray operands = (COSArray) token;
            for (int i = 0; i < operands.size(); i++) {
                Object operand = operands.getObject(i);
                if (operand instanceof COSString) {
                    strings.add(getTextString(operand));
                }
            }
        } else {
            LOG.warn("Expected COSArray operand");
        }
        return strings;
    }

    private String getTextString(Object token) {
        try {
            String string = "";
            if (token instanceof COSString) {
                COSString operand = (COSString) token;
                String value = operand.getString();
                if (value != null) {
                    string = value.getBytes("ISO-8859-1").toString();
                    LOG.debug("Text String [" + value + "]");
                    string = value;
                } else {
                    LOG.warn("NULL Text String!");
                }
            } else {
                LOG.warn("Expected COSString operand");
            }
            return string;
        } catch (UnsupportedEncodingException e) {
            LOG.error(e.toString());
            throw new RuntimeException(e);
        }
    }

    private TextArea beginText(PDFOperator op, TextArea beginText) {
        String operation = op.getOperation();

        if ("BT".equalsIgnoreCase(operation)) {
            beginText = new TextArea(operation);
            LOG.debug(beginText.toString());
        } else if ("ET".equalsIgnoreCase(operation)) {
            beginText = null;
        }
        return beginText;
    }

    private TextCoordinates getTextCoords(List<Object> tokens, int tokenPos, PDFOperator op) {
        TextCoordinates coords = null;
        String operation = op.getOperation();

        if ("td".equalsIgnoreCase(operation)) {
            coords = new TextCoordinates(operation);
            // Move backwards to find coordinates.
            Object yToken = tokens.get(tokenPos - 1);
            Object xToken = tokens.get(tokenPos - 2);
            if ("Td".equals(operation) && xToken instanceof COSInteger && yToken instanceof COSInteger) {
                COSInteger y = (COSInteger) yToken;
                COSInteger x = (COSInteger) xToken;
                coords.setY(y.doubleValue());
                coords.setX(x.doubleValue());
            } else if ("TD".equals(operation) && xToken instanceof COSFloat && yToken instanceof COSFloat) {
                // Move backwards to find coordinates.
                COSFloat y = (COSFloat) yToken;
                COSFloat x = (COSFloat) xToken;
                coords.setY(y.doubleValue());
                coords.setX(x.doubleValue());
            } else {
                LOG.warn("Unexpected Text Coordinates Operation [" + operation + "(" + xToken + ":" + yToken + ")]");
            }
            LOG.debug(coords.toString());
        }
        return coords;
    }

}
