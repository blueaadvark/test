package uk.co.closemf.eclick.transaction.pdf.pdfbox;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uk.co.closemf.eclick.transaction.bean.TextCoordinates;

/*
 * Code lifted from IOCS
 */
public class TextArea {

    private static final Logger LOG = LoggerFactory.getLogger(AgreementForms.class);

    private String op;
    private List<TextCoordinates> coords = new ArrayList<TextCoordinates>();


    public TextArea(String operation) {
        this.op = operation;
    }

    public List<TextCoordinates> getCoords() {
        return this.coords;
    }

    public TextCoordinates addCoord(TextCoordinates coord) {
        TextCoordinates absCoord = coord;
        if (getLastCoord() != null) {
            // Must be relative?
            LOG.debug("Found relative coord:" + coord);
            absCoord = new TextCoordinates(coord.getOp());
            absCoord.setX(getLastCoord().getX() + coord.getX());
            absCoord.setY(getLastCoord().getY() + coord.getY());
            LOG.debug("Made Absolute coord:" + absCoord);
            coords.add(absCoord);
        } else {
            coords.add(coord);
        }
        return absCoord;
    }

    public TextCoordinates getLastCoord() {
        return coords.size() > 0 ? coords.get(coords.size() - 1) : null;
    }

    @Override
    public String toString() {
        return "TextArea [op=" + op + ", coords=" + coords + "]";
    }

}
