package uk.co.closemf.eclick.transaction.processors;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.transaction.exception.EclickTransactionServiceException;
import uk.co.closemf.eclick.transaction.pdf.PdfProcessor;
import uk.co.closemf.eclick.transaction.util.codec.ByteEncoder;


@Component
public class AddSignatureBoxProcessor implements Processor {
    
    @Autowired
    private ByteEncoder encoder;
    
    private static final Logger log = LoggerFactory.getLogger(AddSignatureBoxProcessor.class);
    
    public void process(Exchange exchange) {
        
        log.info("Adding the Signature Capture box");
         
        AgreementTransactionRequest request = exchange.getIn().getBody(AgreementTransactionRequest.class);
        
        if(request.getAgreement() == null || request.getAgreement().getUnsignedAgreementDocument() == null){
            throw new EclickTransactionServiceException("Agreement request has no agreement!");
        }
        
        byte[] agreementDoc = encoder.decode(request.getAgreement().getUnsignedAgreementDocument());
        List<String> placeholders = request.getPlaceholders();
        byte[] agreementDocWithSignatureCapture = PdfProcessor.addSignatureCapture(agreementDoc, placeholders);
        request.getAgreement().setSignatureCaptureAgreementDocument(agreementDocWithSignatureCapture);
        
        exchange.getIn().setBody(request);

     }

}
