package uk.co.closemf.eclick.transaction.processors;

import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.dto.internal.ServiceStatusValues;
import uk.co.closemf.eclick.transaction.exception.EclickTransactionServiceException;

@Component
public class CheckResponseProcessor implements Processor {
    public void process(Exchange exchange) throws Exception {
        AgreementTransactionResponse checkResponse = exchange.getIn().getBody(AgreementTransactionResponse.class);
        
        if(checkResponse.getServiceStatus() == ServiceStatusValues.ERROR){
           throw new EclickTransactionServiceException(checkResponse.getFault(), new Date());
        }

     }

}
