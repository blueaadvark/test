package uk.co.closemf.eclick.transaction.processors;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.transaction.store.DocumentDao;


@Component
public class StoreDocumentStateProcessor implements Processor {
    
    private static final Logger log = LoggerFactory.getLogger(StoreDocumentStateProcessor.class);
    
    @Autowired
    DocumentDao documentDao;
        
    public void process(Exchange exchange) {
        
        log.info("Storing the Unsigned document agreement");
        
        AgreementTransactionRequest request = (AgreementTransactionRequest) exchange.getProperty("originalRequest");
        
        AgreementTransactionResponse response = exchange.getIn().getBody(AgreementTransactionResponse.class);
        
        response.setDocTransactionID(request.getDocTransactionID());
        response.setProposalID(request.getProposalID());
        long docStoreId = documentDao.storeDocument(request);
        response.setUnSignedAgreementDocStoreId(Long.valueOf(docStoreId));
     
     }

}
