package uk.co.closemf.eclick.transaction.route;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.transaction.service.errors.EmailEntityBuilder;
import uk.co.closemf.eclick.transaction.service.errors.FailureBean;

@Component
public class TransactionDLCRoute extends RouteBuilder {

    @Autowired
    FailureBean failureBean;

    @Autowired
    EmailEntityBuilder emailEntityBuilder;
    
    @Value("${direct.error.endpoint}")
    private String errorQueue;
    
    @Override
    public void configure() throws Exception {

        from(errorQueue).routeId("TransactionDLCRoute")
            .bean(failureBean)
            .log(LoggingLevel.ERROR, "Eclick ID Check Service encountered an error. Ref: ${header.ErrorReference}")
            .log(LoggingLevel.ERROR, System.lineSeparator() + "${body.stackTrace}")
            .to("freemarker:template/ErrorEmailTemplate.ftl")
            .bean(emailEntityBuilder)
            .marshal().json(JsonLibrary.Jackson)
            .wireTap("activemq:queue.EMAILService").id("toEmailService")
            .log("${body}")
            .end();
    }
}
