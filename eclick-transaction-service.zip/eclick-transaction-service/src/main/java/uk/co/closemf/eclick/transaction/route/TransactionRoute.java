package uk.co.closemf.eclick.transaction.route;

import javax.xml.bind.JAXBContext;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpComponent;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.apache.camel.spi.DataFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.transaction.processors.AddSignatureBoxProcessor;
import uk.co.closemf.eclick.transaction.processors.CheckResponseProcessor;
import uk.co.closemf.eclick.transaction.processors.StoreDocumentStateProcessor;


@Component
public class TransactionRoute extends RouteBuilder {
    
    public static final String ROUTE_ID = "TransactionRoute";

    @Value("${activemq.queue.input}")
    private String mqInput;
    
    @Value("${activemq.queue.response}")
    private String mqResponse;
    
    @Value("${rest.transaction.endpoint}")
    private String restEndpoint;
    
    @Value("${direct.error.endpoint}")
    private String errorQueue;
    
    @Autowired
    AddSignatureBoxProcessor addSignatureBoxProcessor;
    
    @Autowired
    StoreDocumentStateProcessor storeDocumentStateProcessor;
    
    @Autowired
    CheckResponseProcessor checkResponseProcessor;
      
    @Override
    public void configure() throws Exception {
        
        JAXBContext jaxbContext = JAXBContext.newInstance(AgreementTransactionRequest.class, AgreementTransactionResponse.class);
        DataFormat jaxb = new JaxbDataFormat(jaxbContext);
           
        HttpComponent httpComponent = new HttpComponent();
        getContext().addComponent("http", httpComponent);
            
        errorHandler(deadLetterChannel(errorQueue).useOriginalMessage());

        from(mqInput).routeId(ROUTE_ID)
            .log("${body}")
            .unmarshal(jaxb)
            .setProperty("originalRequest", body())
            .process(addSignatureBoxProcessor).id("addSignatureBoxProcessor") 
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader(Exchange.CONTENT_TYPE, constant(MediaType.APPLICATION_JSON))
            .to(restEndpoint)
            .marshal(jaxb)
            .process(checkResponseProcessor).id("checkResponseProcessor")
            .process(storeDocumentStateProcessor).id("storeDocumentStateProcessor")
            .to(mqResponse);                
    }   

}