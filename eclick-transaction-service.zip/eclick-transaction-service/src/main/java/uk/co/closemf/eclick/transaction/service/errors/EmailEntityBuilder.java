package uk.co.closemf.eclick.transaction.service.errors;

import org.apache.camel.Body;
import org.apache.camel.Header;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.co.closemf.common.data.constants.EmailType;
import uk.co.closemf.common.data.entity.EmailEntity;


@Component
public class EmailEntityBuilder {

    @Value("${email.sender}")
    private String sender;

    @Value("${email.recipient}")
    private String recipient;

    public EmailEntity buildEmailEntity(@Header("ErrorReference") String errorRef, @Body String body){
        EmailEntity emailEntity = new EmailEntity();

        emailEntity.setAppId("eclick-idcheck-service");
        emailEntity.setSubjectLine(String.format("Eclick ID Check Service Error (REF: %s)", errorRef));
        emailEntity.setMailContent(body);
        emailEntity.setRecipient(recipient);
        emailEntity.setSender(sender);
        emailEntity.setEmailType(EmailType.HTML);

        return emailEntity;
    }
}
