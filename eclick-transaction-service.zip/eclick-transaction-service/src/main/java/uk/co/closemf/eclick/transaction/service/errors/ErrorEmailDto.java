package uk.co.closemf.eclick.transaction.service.errors;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ErrorEmailDto {
    private String hostName;
    private String ipAddress;
    private String request;
    private String stackTrace;

    public ErrorEmailDto(String hostName, String ipAddress, String request, String stackTrace) {
        this.hostName = hostName;
        this.ipAddress = ipAddress;
        this.request = request;
        this.stackTrace = stackTrace;
    }

    public String getHostName() {
        return hostName;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public String getRequest() {
        return request;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }
    
    @Override
    public String toString() {      
        return ToStringBuilder.reflectionToString(this);
        
    }
}
