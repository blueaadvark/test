package uk.co.closemf.eclick.transaction.service.errors;

import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.transaction.exception.EclickTransactionServiceException;


@Component
public class FailureBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(FailureBean.class);

    public void process(Object eclickObject, Exchange exchange) {
        String errorReference = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmssSSS"));
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

        String hostName;
        String ipAddress;
        try {
            ipAddress = InetAddress.getLocalHost().getHostAddress();
            hostName = InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            LOGGER.debug("The local host name could not be resolved into an address", e);
            hostName = "Couldn't be resolved";
            ipAddress = "Couldn't be resolved";
        }

        exchange.getIn().setHeader("hostName", "" + hostName);
        exchange.getIn().setHeader("ipAddress", "" + ipAddress);

        exchange.getIn().setHeader("ErrorReference", errorReference);
        exchange.getIn().setHeader("ErrorMessage", "" + exception.getMessage());

        StringBuilder sb = new StringBuilder(exception.getMessage() + System.lineSeparator() + getStackTraceString(exception));
        String stackTraceString = getCauseMessage(exception.getCause(), sb);

        String xmlString;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(eclickObject.getClass());
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            StringWriter sw = new StringWriter();
            marshaller.marshal(eclickObject, sw);
            xmlString = sw.toString();
        } catch (JAXBException e) {
            LOGGER.debug("Something went wrong when marshalling Response for error message", e);
            throw new EclickTransactionServiceException("Something went wrong when marshalling Response for error message", e);
        }

        ErrorEmailDto errorEmailDto = new ErrorEmailDto(hostName, ipAddress, xmlString, stackTraceString);

        exchange.getIn().setBody(errorEmailDto);
    }

    /**
     * This is a recursive method to extract all exception messages and stacktrace in the exception chain
     *
     * @param cause The exception that's thrown
     * @param message
     * @return
     */
    private String getCauseMessage(Throwable cause, StringBuilder message) {
        if (cause != null) {
            message.append(System.lineSeparator())
                    .append("Caused by: ")
                    .append(cause.toString())
                    .append(System.lineSeparator())
                    .append(getStackTraceString(cause));

            getCauseMessage(cause.getCause(), message);
        }
        return message.toString();
    }

    private String getStackTraceString(Throwable cause) {
        StringBuilder stackTrace = new StringBuilder();
        for (StackTraceElement stackTraceElement : cause.getStackTrace()) {
            stackTrace.append(stackTraceElement).append(System.lineSeparator());
        }
        return stackTrace.toString();
    }
}
