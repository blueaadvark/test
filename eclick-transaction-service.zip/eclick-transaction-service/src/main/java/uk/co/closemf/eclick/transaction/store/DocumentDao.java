package uk.co.closemf.eclick.transaction.store;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.transaction.bean.UnsignedAgreementDoc;
import uk.co.closemf.eclick.transaction.util.codec.ByteEncoder;
import uk.co.cmf.docs.MultiSourceDocument;
import uk.co.cmf.docs.dao.DocStoreDao;


@Component
public class DocumentDao {
    
    @Autowired
    private DocStoreDao docStore;
    
    @Autowired
    private ByteEncoder encoder;
    
    public long storeDocument(AgreementTransactionRequest request) {
         String encodedDoc = encoder.encode(request.getAgreement().getSignatureCaptureAgreementDocument());
         return storeDocument(new UnsignedAgreementDoc(encodedDoc, request.getProposalID()));

    }
    
    private long storeDocument(MultiSourceDocument doc) {
        doc.setDocumentId(docStore.store(doc));
        return doc.getDocumentId();
    }

}
