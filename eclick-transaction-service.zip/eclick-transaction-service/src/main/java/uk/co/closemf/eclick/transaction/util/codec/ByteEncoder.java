/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.transaction.util.codec;

/**
 * @author tasmith
 *
 */
public interface ByteEncoder {

    byte[] decode(String encoded);

    String encode(byte[] bytes);

}
