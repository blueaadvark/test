/**
 * Close Motor Finance Ltd
 * Copyright 2013
 */
package uk.co.closemf.eclick.transaction.util.codec;

import org.springframework.stereotype.Component;

import com.mig.Base64;

/**
 * @author tasmith
 * 
 */
@Component
public class MigBase64Encoder implements ByteEncoder {

    private boolean lineSep = false;

    public boolean isLineSep() {
        return lineSep;
    }

    public void setLineSep(boolean lineSep) {
        this.lineSep = lineSep;
    }

    /**
     * @see uk.co.cmf.util.codec.ByteEncoder#decode(java.lang.String)
     */
    @Override
    public byte[] decode(String encoded) {
        return Base64.decode(encoded.getBytes());
    }

    /**
     * @see uk.co.cmf.util.codec.ByteEncoder#encode(byte[])
     */
    @Override
    public String encode(byte[] bytes) {
        return Base64.encodeToString(bytes, isLineSep());
    }

}
