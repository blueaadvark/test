package uk.co.closemf.eclick.transaction.processors;

import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;
import uk.co.closemf.eclick.transaction.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = {EclickTransactionServiceApplication.class})
@ActiveProfiles("test")
public class AddSignatureBoxProcessorFileTest extends CamelTestSupport{
    
    @Autowired
    private AddSignatureBoxProcessor addSignatureBoxProcessor;

    @Value("classpath:eDocTrans.xml")
    private Resource agreementTransactionRequestXml;

    @Test
    public void mqResponseHasTransactionResponseMockedPdfProcessorTest() throws Exception {

        
        AgreementTransactionRequest request = TestUtil.getTestDtoFromXML(AgreementTransactionRequest.class, agreementTransactionRequestXml);

        
        DefaultExchange exchange = new DefaultExchange(context);
        
        exchange.getIn().setBody(request);
        addSignatureBoxProcessor.process(exchange);
        
        assertNotNull(request.getAgreement().getSignatureCaptureAgreementDocument());

    }
}