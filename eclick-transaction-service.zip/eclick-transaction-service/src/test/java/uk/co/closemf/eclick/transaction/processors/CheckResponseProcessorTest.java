package uk.co.closemf.eclick.transaction.processors;

import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.bind.annotation.ExceptionHandler;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;
import uk.co.closemf.eclick.transaction.exception.EclickTransactionServiceException;
import uk.co.closemf.eclick.transaction.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = {EclickTransactionServiceApplication.class})
@ActiveProfiles("test")
public class CheckResponseProcessorTest extends CamelTestSupport{
    
    @Autowired
    private CheckResponseProcessor checkResponseProcessor;

    @Value("classpath:eDocTransResponse.xml")
    private Resource agreementTransactionResponseXml;
    
    @Value("classpath:agreementTransactionResponse.xml")
    private Resource agreementErrorResponseXml;

    @Test
    public void CheckValidResponseProcessorTest() throws Exception {

        
        AgreementTransactionResponse response = TestUtil.getTestDtoFromXML(AgreementTransactionResponse.class, agreementTransactionResponseXml);
        
        DefaultExchange exchange = new DefaultExchange(context);
        
        exchange.getIn().setBody(response);
        checkResponseProcessor.process(exchange);
        
        assertNotNull(exchange.getIn().getBody());

    }
    
    @Test(expected = EclickTransactionServiceException.class)
    public void CheckInvalidResponseProcessorTest() throws Exception {

        
        AgreementTransactionResponse response = TestUtil.getTestDtoFromXML(AgreementTransactionResponse.class, agreementErrorResponseXml);
        
        DefaultExchange exchange = new DefaultExchange(context);
        
        exchange.getIn().setBody(response);
        checkResponseProcessor.process(exchange);

    }
}