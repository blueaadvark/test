package uk.co.closemf.eclick.transaction.processors;

import static org.mockito.Mockito.when;

import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.dto.internal.AgreementTransactionRequest;
import uk.co.closemf.eclick.dto.internal.AgreementTransactionResponse;
import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;
import uk.co.closemf.eclick.transaction.store.DocumentDao;
import uk.co.closemf.eclick.transaction.test.util.TestUtil;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = {EclickTransactionServiceApplication.class})
@ActiveProfiles("test")
public class StoreDocumentStateProcessorTest extends CamelTestSupport{
    
    @InjectMocks
    private StoreDocumentStateProcessor storeDocumentStateProcessor;
    
    @Mock
    private DocumentDao documentDao;
    
    @Value("classpath:agreementTransactionRequest.xml")
    private Resource agreementTransactionRequestXml;
    
    @Value("classpath:agreementTransactionResponse.xml")
    private Resource agreementTransactionResponseXml;

    @Test
    @DirtiesContext
    public void mqResponseHasTransactionResponseTest() throws Exception {
               
        AgreementTransactionResponse response = TestUtil.getTestDtoFromXML(AgreementTransactionResponse.class, agreementTransactionResponseXml);
        AgreementTransactionRequest request = TestUtil.getTestDtoFromXML(AgreementTransactionRequest.class, agreementTransactionRequestXml);
 
        DefaultExchange exchange = new DefaultExchange(context);
        exchange.setProperty("originalRequest", request);
                
        when(documentDao.storeDocument(request)).thenReturn(1L);
        
        exchange.getIn().setBody(response);
        storeDocumentStateProcessor.process(exchange);
        
        assertEquals(response.getDocTransactionID(), request.getDocTransactionID());
        assertEquals(response.getProposalID(), request.getProposalID());
        assertEquals(response.getUnSignedAgreementDocStoreId(), Long.valueOf(1L));
    }
    
    @After
    public void teardown() throws Exception{
        context.stop();
    }
}