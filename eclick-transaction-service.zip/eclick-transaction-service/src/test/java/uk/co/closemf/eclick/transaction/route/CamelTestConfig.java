package uk.co.closemf.eclick.transaction.route;

import org.apache.camel.CamelContext;
import org.apache.camel.Route;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.transaction.EclickTransactionServiceApplication;

@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(classes = { EclickTransactionServiceApplication.class, CamelTestConfig.class})
@ActiveProfiles("test")
public class CamelTestConfig extends CamelTestSupport{

    @Autowired
    CamelContext camelContext;

    @DirtiesContext
    @Test
    public void shouldCreateRoutes() throws InterruptedException{
        assertEquals("There should be 2 route1 in the camel context", 2, camelContext.getRoutes().size());
        Route route = camelContext.getRoute(TransactionRoute.ROUTE_ID);
        assertNotNull(route);
    }
    
    @DirtiesContext
    @Test
    public void shouldCreateCamelContext() {
        assertNotNull(camelContext);
    }

}
