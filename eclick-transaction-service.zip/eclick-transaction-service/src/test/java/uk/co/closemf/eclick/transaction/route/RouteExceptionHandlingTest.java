package uk.co.closemf.eclick.transaction.route;

import java.io.IOException;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.CamelSpringBootRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.io.Resource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import uk.co.closemf.eclick.transaction.test.util.TestUtil;


@RunWith(CamelSpringBootRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@UseAdviceWith
public class RouteExceptionHandlingTest {
    
    @Produce(uri = "activemq:testQueue")
    private ProducerTemplate template;
    
    @EndpointInject(uri = "mock:catchMessages")
    private MockEndpoint resultEndpoint;
    
    @EndpointInject(uri = "mock:errorMessages")
    private MockEndpoint errorEndpoint;
    
    @Value("classpath:agreementTransactionFault.xml")
    private Resource agreementTransactionFaultXml;

    @Autowired
    private CamelContext context;

    @Before
    public void mockEndpoints() throws Exception {

        AdviceWithRouteBuilder mockDestination = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http://localhost:8080/notSure")
                    .skipSendToOriginalEndpoint()
                    .to("mock:catchMessages");

            }
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockDestination);
        
        AdviceWithRouteBuilder mockErrorResponse = new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("direct:errorQueue")
                    .skipSendToOriginalEndpoint()
                    .to("mock:errorMessages");         
            }
            
        };
        context.getRouteDefinitions().get(0)
            .adviceWith(context, mockErrorResponse);
        
        context.start();
    }

    @Test
    @DirtiesContext
    public void testExceptionHandling() throws IOException, InterruptedException {
        errorEndpoint.setExpectedMessageCount(1);
        String requestXmlString = TestUtil.getStringFromFile(agreementTransactionFaultXml);
        template.sendBody(requestXmlString);
        errorEndpoint.assertIsSatisfied();
    }

    @After
    public void teardown() throws Exception{
        context.stop();
    }
}
