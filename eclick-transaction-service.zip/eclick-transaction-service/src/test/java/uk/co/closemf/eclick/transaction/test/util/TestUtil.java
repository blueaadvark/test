package uk.co.closemf.eclick.transaction.test.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.Resource;

public class TestUtil {

    @SuppressWarnings("unchecked")
    public static <T> T getTestDtoFromXML(Class<T> type, Resource resource) throws IOException, JAXBException {
        JAXBContext context  = JAXBContext.newInstance(type);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        return (T) unmarshaller.unmarshal(resource.getInputStream());
    }
    
    public static String getStringFromFile(Resource resource) throws IOException {
        File file = resource.getFile();
        return new String(Files.readAllBytes(file.toPath()));
    }
}
